import React from 'react'

const Loding = () => {
  return (
    <div>
        <div className='spinner'>

        </div>
    </div>
  )
}

export default Loding